var http = require('http');
var url = require('url');
var querystring = require('querystring');

var server = http.createServer(function(req, res) {
    var params = querystring.parse(url.parse(req.url).query);
    res.writeHead(200, {"Content-Type": "text/plain"});
    if ('browser' in params && 'address' in params) {
        var browser = params['browser'];
        var address = params['address'];
        var retour = run_browser(browser,address);
        if(retour = true){
                res.write('ok');
        }else{
                res.write('notok');
        }
    }
    else {
        res.write("il manque le navigateur ou l'adresse");
    }
    res.end();
});
// C:\Program Files (x86)\Google\Chrome\Application
function run_browser(browser,address){
        if(browser == 'chrome'){
			   var cp = require('child_process'),
               url_to_open = address;
               cp.spawn('c:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe', ['-new-tab', url_to_open]);
               console.log('Navigateur =  chrome' + ' adresse =   ' + address)
        }
        if(browser == 'firefox'){
                var cp = require('child_process'),
                url_to_open = address;
                cp.spawn('c:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe', ['-new-tab', url_to_open]);
                console.log('Navigateur =  chrome' + ' adresse =   ' + address)
        }
        if(browser == 'explorer'){
                var cp = require('child_process'),
                url_to_open = address;
                cp.spawn('c:\\Program Files\\Internet Explorer\\iexplore.exe', [url_to_open]);
                console.log('Navigateur =  chrome' + ' adresse =   ' + address)
        }

        return true

}

server.listen(8082);

//http://192.168.1.97:8080/?browser=chrome&address=http://www.google.be