<?php
$user_mysql = 'USER_MYSQL';
$pass_mysql = 'PASS_MYSQL';
$db_mysql = 'BD_COCKTAILS';
$host_mysql = 'ADDRESSE SERVEUR MYSQL';
try {
    $dbh = new PDO('mysql:host='.$host_mysql.';dbname='.$db_mysql, $user_mysql, $pass_mysql, array(
    PDO::ATTR_PERSISTENT => true,
	PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"
	));
} 
catch (PDOException $e) {
    print "Erreur !: " . $e->getMessage() . "<br/>";
    die();
}

if(isset($_GET['sarah'])){
	// Liste alcool 
	if($_GET['sarah'] == "list_alcool" ){
		$sql = 'SELECT * FROM `liste_alcool` ORDER BY `nom_alcool` ASC';    
		$req = $dbh->query($sql); 
		$Json = '{"liste": [';   
 		while($row = $req->fetch()) { 
			$nom = $row['nom_alcool'];
			$quantite = $row['quantite_alcool'];
			$id = $row['id_alcool'];
		
			$Json .= '{"nom":"'.$nom.'","quantite":"'.$quantite.'","id":"'.$id.'"},';
		   // {"nom":"'.$nom.'","quantite":"'.$quantite.'","id":"'.$id'"}
			//$retour = $retour . "nom : " . $row['nom_alcool'] . " quantité : " . $row['quantite_alcool'] . " id : " . $row['id_alcool'] . " ---- " ;
      	}    
 		$req->closeCursor(); 
		$Json .= ']}';
		echo $Json;
		
	}//Fin  Liste alcool
	
	// Liste soft
	if($_GET['sarah'] == "list_soft" ){
		$sql = 'SELECT * FROM `liste_soft` ORDER BY `nom_soft` ASC';    
		$req = $dbh->query($sql);    
 		$Json = '{"liste": [';   
		while($row = $req->fetch()) {   
			$nom = $row['nom_soft'];
			$quantite = $row['quantite_soft'];
			$id = $row['id_soft'];
		
			$Json .= '{"nom":"'.$nom.'","quantite":"'.$quantite.'","id":"'.$id.'"},'; 
			
      	}    
 		$req->closeCursor(); 
		$Json .= ']}';
	}// Fin Liste soft
}

if(isset($_POST['type_req'])){
	/*******************************************/
	/*          AJOUT ALCOOLS ET SOFTS         */
	/*******************************************/
	// Ajout alcool dans db
	if($_POST['type_req'] == "ajout_alcool" ){
		$nom = addslashes($_POST['nom']);
		$quantite = addslashes($_POST['quantite']);
		
		$sth = $dbh->prepare("INSERT INTO liste_alcool (id_alcool,nom_alcool,quantite_alcool) VALUES('','".$nom."', '".$quantite."')");
		$sth->execute();
		
		$last_id = $dbh->lastInsertId();
			
		echo $last_id;
	}//Fin  Ajout alcool dans db
	
	// Ajout soft dans db
	if($_POST['type_req'] == "ajout_soft" ){
		$nom = addslashes($_POST['nom']);
		$quantite = addslashes($_POST['quantite']);
		
		$sth = $dbh->prepare("INSERT INTO liste_soft (id_soft,nom_soft,quantite_soft) VALUES('','".$nom."', '".$quantite."')");
		$sth->execute();
		
		$last_id = $dbh->lastInsertId();
		
		echo $last_id;
	}// Fin Ajout soft dans db
	/**********************************************/
	/*         FIN AJOUT ALCOOLS ET SOFTS         */
	/**********************************************/
	
	
	
	
	/*******************************************/
	/*          LISTE ALCOOLS ET SOFTS         */
	/*******************************************/
	// Liste alcool 
	if($_POST['type_req'] == "list_alcool" ){
		$sql = 'SELECT * FROM `liste_alcool` ORDER BY `nom_alcool` ASC';    
		$req = $dbh->query($sql); 
		$Json = '{"liste": [';   
 		while($row = $req->fetch()) { 
			$nom = $row['nom_alcool'];
			$quantite = $row['quantite_alcool'];
			$id = $row['id_alcool'];
		
			$Json .= '{"nom":"'.$nom.'","quantite":"'.$quantite.'","id":"'.$id.'"},';
		   // {"nom":"'.$nom.'","quantite":"'.$quantite.'","id":"'.$id'"}
			//$retour = $retour . "nom : " . $row['nom_alcool'] . " quantité : " . $row['quantite_alcool'] . " id : " . $row['id_alcool'] . " ---- " ;
      	}    
 		$req->closeCursor(); 
		$Json .= ']}';
		echo $Json;
		
	}//Fin  Liste alcool
	
	// Liste soft
	if($_POST['type_req'] == "list_soft" ){
		$sql = 'SELECT * FROM `liste_soft` ORDER BY `nom_soft` ASC';    
		$req = $dbh->query($sql);    
 		$Json = '{"liste": [';   
		while($row = $req->fetch()) {   
			$nom = $row['nom_soft'];
			$quantite = $row['quantite_soft'];
			$id = $row['id_soft'];
		
			$Json .= '{"nom":"'.$nom.'","quantite":"'.$quantite.'","id":"'.$id.'"},'; 
			
      	}    
 		$req->closeCursor(); 
		$Json .= ']}';
		echo $Json;
	}// Fin Liste soft
	/**********************************************/
	/*         FIN LISTE ALCOOLS ET SOFTS         */
	/**********************************************/
	
	/********************************************/
	/*          DELETE ALCOOLS ET SOFTS         */
	/********************************************/
	// delete alcool 
	if($_POST['type_req'] == "delete_alcool" ){
		$id_post=$_POST['id'];
		$sth = $dbh->prepare("DELETE FROM `liste_alcool` WHERE id_alcool='".$id_post."'");  
		$sth->execute();
		echo "ok";
		
	}//Fin  delete alcool
	
	// delete alcool 
	if($_POST['type_req'] == "delete_soft" ){
		$id_post=$_POST['id'];
		$sth = $dbh->prepare("DELETE FROM `liste_soft` WHERE id_soft='".$id_post."'");  
		$sth->execute();
		echo "ok";
		
	}//Fin  delete alcool
	
	/***********************************************/
	/*         FIN DELETE ALCOOLS ET SOFTS         */
	/***********************************************/
	
	
	
	
	/********************************************/
	/*          UPDATE ALCOOLS ET SOFTS         */
	/********************************************/
	// delete alcool 
	if($_POST['type_req'] == "update_alcool" ){
		$id_post=$_POST['id'];
		$valeur = addslashes($_POST['valeur']);
		$sth = $dbh->prepare("UPDATE `liste_alcool` SET `quantite_alcool`='".$valeur."' WHERE `id_alcool`=".$id_post);
		$sth->execute();
		echo "ok";
		
	}//Fin  delete alcool
	
	// delete alcool 
	if($_POST['type_req'] == "update_soft" ){
		$id_post=$_POST['id'];
		$valeur = addslashes($_POST['valeur']);
		$sth = $dbh->prepare("UPDATE `liste_soft` SET `quantite_soft`='".$valeur."' WHERE `id_soft`=".$id_post); 
		$sth->execute();
		echo "ok";
		
	}//Fin  delete alcool
	
	/***********************************************/
	/*         FIN UPDATE ALCOOLS ET SOFTS         */
	/***********************************************/
	
}
?>