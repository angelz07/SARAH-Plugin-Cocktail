<?php
$user_mysql = 'USER_MYSQL';
$pass_mysql = 'PASS_MYSQL';
$db_mysql = 'BD_COCKTAILS';
$host_mysql = 'ADDRESSE SERVEUR MYSQL';
try {
    $dbh = new PDO('mysql:host='.$host_mysql.';dbname='.$db_mysql, $user_mysql, $pass_mysql, array(
    PDO::ATTR_PERSISTENT => true,
	PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"
	));
} 
catch (PDOException $e) {
    print "Erreur !: " . $e->getMessage() . "<br/>";
    die();
}

if(isset($_GET['sarah'])){
	// Liste alcool 
	if($_GET['sarah'] == "list_alcool" ){
	// Liste alcool 
	
		$sql = 'SELECT * FROM `liste_alcool` ORDER BY `nom_alcool` ASC';    
		$req = $dbh->query($sql); 
		$Json = '{"liste": [';   
 		while($row = $req->fetch()) { 
			$nom = $row['nom_alcool'];
			$quantite = $row['quantite_alcool'];
			$id = $row['id_alcool'];
		
			$Json .= '{"nom":"'.$nom.'","quantite":"'.$quantite.'","id":"'.$id.'"},';
		   // {"nom":"'.$nom.'","quantite":"'.$quantite.'","id":"'.$id'"}
			//$retour = $retour . "nom : " . $row['nom_alcool'] . " quantité : " . $row['quantite_alcool'] . " id : " . $row['id_alcool'] . " ---- " ;
      	}    
 		$req->closeCursor(); 
		$Json .= ']}';
		
		echo $Json;
	}
	
	// Liste soft
	if($_GET['sarah'] == "list_soft" ){
		$sql = 'SELECT * FROM `liste_soft` ORDER BY `nom_soft` ASC';    
		$req = $dbh->query($sql);    
 		$Json = '{"liste": [';   
		while($row = $req->fetch()) {   
			$nom = $row['nom_soft'];
			$quantite = $row['quantite_soft'];
			$id = $row['id_soft'];
		
			$Json .= '{"nom":"'.$nom.'","quantite":"'.$quantite.'","id":"'.$id.'"},'; 
			
      	}    
 		$req->closeCursor(); 
		$Json .= ']}';
	// Fin Liste soft
        
		echo $Json;
	}
}
?>