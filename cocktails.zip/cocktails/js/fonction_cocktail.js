$(document).ready(function() {
	gestion_bouton();
	affichage_alcools();
	affichage_softs();

	

});

/*****************************************/
/* Ajout dans la BD des alcools et softs */
/*****************************************/
function gestion_bouton(){
	// Bouton bt_ajout_alcool click
	$("#bt_ajout_alcool").click(function() {
		var type_req = "ajout_alcool";
		var nom = $("#nom_bouteille_alcool").val();
		var quantite = $("#quantite_bouteille_alcool").val();
		if(nom != "" && quantite != ""){
			var data = 'type_req=' + type_req + '&nom=' + nom + '&quantite=' + quantite;
			$.ajax({
				type : "POST",
				url : "./scripts_php/fonction_php.php",
				data : data,
				success: function(server_response){
					if(server_response){
						$('#nom_bouteille_alcool').val("");
						$('#quantite_bouteille_alcool').val("");
						affichage_alcools();
					}
					else{
						alert("il y a eu un souci");	
					}
				 }
			});
		}
		else{
			alert("il manque soit le nom, soit la quantité, soit les 2")	
		}
	});
	
	// Bouton bt_ajout_soft click
	$("#bt_ajout_soft").click(function() {
		var type_req = "ajout_soft";
		var nom = $("#nom_bouteille_soft").val();
		var quantite = $("#quantite_bouteille_soft").val();
		if(nom != "" && quantite != ""){
			var data = 'type_req=' + type_req + '&nom=' + nom + '&quantite=' + quantite;
			$.ajax({
				type : "POST",
				url : "./scripts_php/fonction_php.php",
				data : data,
				success: function(server_response){
					if(server_response){
						$('#nom_bouteille_soft').val("");
						$('#quantite_bouteille_soft').val("");
						affichage_softs();
					}
					else{
						alert("il y a eu un souci");	
					}
				 }
			});
		}
		else{
			alert("il manque soit le nom, soit la quantité, soit les 2")	
		}
	});
}
/*-------------------------------------------*/
/* Fin Ajout dans la BD des alcools et softs */
/*-------------------------------------------*/



/**********************************/
/* Affichage des alcools et softs */
/**********************************/
function affichage_alcools(){
	var type_req = "list_alcool";
	var data = 'type_req=' + type_req;
	$.ajax({
		type : "POST",
		url : "./scripts_php/fonction_php.php",
		data : data,
		success: function(server_response){
			var donnees = eval('('+server_response+')');
			var html_data='<table width="100%" border="0" class="tableau_liste">';
			html_data = html_data + '<tr class="tr_liste">';
			html_data = html_data + '<td class="td_liste_label"><label class="liste_label_titre">Nom Alcool</label></td><td class="td_liste_quantite"><label class="liste_label_titre" >Quantité(bouteille)</label></td><td class="td_liste_croix_titre" ><input name="" type="hidden" value=""></td>'
			html_data = html_data + '</tr>';
			for (var i =0;i<donnees.liste.length;i++){
				
				//insertion d'un tableau
				html_data = html_data + '<tr class="tr_liste">';
				html_data = html_data + '<td class="td_liste_label"><label class="liste_label">' + donnees.liste[i].nom + '</label></td><td class="td_liste_quantite"><input onchange="update_alcool($(this));" name="' + donnees.liste[i].id + '" class="input_liste_quantite" type="text" value="' + donnees.liste[i].quantite + '"></td><td id="' + donnees.liste[i].id + '" class="td_liste_croix" onClick="delete_alcool(this);" ></td>'
				html_data = html_data + '</tr>';
				//donnees.liste[i].nom)
			}
			html_data = html_data + '</table>';
			$('#contenu_liste_alcool').empty();
			$('#contenu_liste_alcool').html(html_data);
			
		}
	});	
}

function affichage_softs(){
	var type_req = "list_soft";
	var data = 'type_req=' + type_req;
	$.ajax({
		type : "POST",
		url : "./scripts_php/fonction_php.php",
		data : data,
		success: function(server_response){
			var donnees = eval('('+server_response+')');
			var html_data='<table width="100%" border="0" class="tableau_liste">';
			html_data = html_data + '<tr class="tr_liste">';
			html_data = html_data + '<td class="td_liste_label"><label class="liste_label_titre">Nom Soft</label></td><td class="td_liste_quantite"><label class="liste_label_titre" >Quantité(bouteille)</label></td><td class="td_liste_croix_titre" ><input name="" type="hidden" value=""></td>'
			html_data = html_data + '</tr>';
			for (var i =0;i<donnees.liste.length;i++){
				
				//insertion d'un tableau
				html_data = html_data + '<tr class="tr_liste">';
				html_data = html_data + '<td class="td_liste_label"><label class="liste_label">' + donnees.liste[i].nom + '</label></td><td class="td_liste_quantite"><input onchange="update_soft($(this));" name="' + donnees.liste[i].id + '" class="input_liste_quantite" type="text" value="' + donnees.liste[i].quantite + '"></td><td id="' + donnees.liste[i].id + '" class="td_liste_croix" onClick="delete_soft(this);" ></td>'
				html_data = html_data + '</tr>';
				//donnees.liste[i].nom)
			}
			html_data = html_data + '</table>';
			$('#contenu_liste_soft').empty();
			$('#contenu_liste_soft').html(html_data);
		}
	});	
}

/*------------------------------------*/
/* Fin Affichage des alcools et softs */
/*------------------------------------*/

/*******************************/
/* Delete des alcools et softs */
/*******************************/
function delete_alcool(arg){
	var confirmation = confirm("Voulez-vous vraiment effacer cet alcool ?")
	if (confirmation){
		  	var id = arg.id;
			var type_req = "delete_alcool"; 
			var data = 'type_req=' + type_req + '&id=' + id ;
			$.ajax({
				type : "POST",
				url : "./scripts_php/fonction_php.php",
				data : data,
				success: function(server_response){
					if(server_response == "ok"){
							affichage_alcools();
					}
					else{
						alert("il y a eu un souci");	
					}
				 }
			});
	}	
}

function delete_soft(arg){
	var confirmation = confirm("Voulez-vous vraiment effacer cee soft ?")
	if (confirmation){
		var id = arg.id;
		var type_req = "delete_soft"; 
		var data = 'type_req=' + type_req + '&id=' + id ;
		$.ajax({
			type : "POST",
			url : "./scripts_php/fonction_php.php",
			data : data,
			success: function(server_response){
				if(server_response == "ok"){
					affichage_softs();
				}
				else{
					alert("il y a eu un souci");	
				}
			 }
		});
	}
}

/*----------------------------------*/
/* Fin Delete des alcools et softs */
/*---------------------------------*/


/*******************************/
/* Update des alcools et softs */
/*******************************/
function update_alcool(arg){
	var id = arg.attr("name");
	var valeur = arg.val();
	var type_req = "update_alcool"; 
	var data = 'type_req=' + type_req + '&id=' + id + '&valeur=' + valeur;
	$.ajax({
		type : "POST",
		url : "./scripts_php/fonction_php.php",
		data : data,
		success: function(server_response){
			alert(server_response)
		 }
	});
}

function update_soft(arg){
	var id = arg.attr("name");
	var valeur = arg.val();
	var type_req = "update_soft"; 
	var data = 'type_req=' + type_req + '&id=' + id + '&valeur=' + valeur;
	$.ajax({
		type : "POST",
		url : "./scripts_php/fonction_php.php",
		data : data,
		success: function(server_response){
			alert(server_response)
		 }
	});
}
/*---------------------------------*/
/* Fin Update des alcools et softs */
/*---------------------------------*/
