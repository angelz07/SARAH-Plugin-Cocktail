<!DOCTYPE html>
<html lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/normalise.css">
<link href="css/trontastic/jquery-ui-1.10.3.custom.css" rel="stylesheet">
<link rel="stylesheet" href="css/style_maison.css">
<script src="js/jquery-1.9.1.js"></script>
<script src="js/jquery-ui-1.10.3.custom.js"></script>
<script src="js/fonction_cocktail.js"></script>



<head>
  <title>Gestion Cocktails</title>
</head>
<body>
	<div id="titre_principal">
			<img src="img/titre_cocktail.png">
	</div><!-- fin div titre_principal -->
	
	<div id="base">
		<div id="contenu_principal">
        	<table width="100%" border="0">
              <tr>
                <td>
                	<center>
                    <div id="encodage_alcool">
                        <fieldset><legend>Encodage Alcool</legend>
                            <label for="nom_bouteille" class="titre_input">Nom Bouteille :</label>
                            <input type="text" name="nom_bouteille_alcool" id="nom_bouteille_alcool" class="input_alcool input_text_nom" />
                            <label for="quantite_bouteille_alcool" class="titre_input">Quantité Bouteille :</label>
                            <input type="text" name="quantite_bouteille_alcool" id="quantite_bouteille_alcool" class="input_alcool input_text_quantite" />
                            <input name="bt_ajout_alcool" id="bt_ajout_alcool" type="button" class="boutton_ajout" value="  Ajout  ">
                        </fieldset>
                    </div>
                    </center>
            	</td>
                <td>
               		<center>
                	<div id="encodage_soft">
                        <fieldset>
                            <legend>Encodage Soft</legend>
                                <label for="nom_bouteille_soft" class="titre_input">Nom Bouteille :</label>
                                <input type="text" name="nom_bouteille_soft" id="nom_bouteille_soft" class="input_soft input_text_nom" />
                                <label for="quantite_bouteille_soft" class="titre_input">Quantité Bouteille :</label>
                                <input type="text" name="quantite_bouteille_soft" id="quantite_bouteille_soft" class="input_soft input_text_quantite" />
                                <input name="bt_ajout_soft" id="bt_ajout_soft" type="button" class="boutton_ajout" value="  Ajout  ">
                        </fieldset>
                    </div>
                	</center>
                </td>
              </tr>
              <tr>
                <td>
                	<center>
                	<div id="liste_alcool">
                        <fieldset>
                            <legend>Liste Alcool</legend>
                            <div id="contenu_liste_alcool"></div>
                        </fieldset>
                    </div>
                    </center>
                </td>
                <td>
                	<center>
                	<div id="liste_soft">
                        <fieldset>
                            <legend>Liste Soft</legend>
                            <div id="contenu_liste_soft"></div>
                        </fieldset>
                    </div>
                    </center>
                </td>
              </tr>
            </table>
		</div><!-- fin div contenu_principal -->	
		
	</div><!-- fin div base -->	

</body>
</html>